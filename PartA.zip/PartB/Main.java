import java.io.IOException;

public class Main {
  public static void main(String[] args) throws IOException {
    Trader t1 = new Trader();
    t1.load("Unilever.csv"); 

    System.out.println(t1.trade());
  }
}
